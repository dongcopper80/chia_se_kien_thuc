package com.dongcopper80.jms;

import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

/**
 *
 * @author Nguyễn Thúc Đồng (dongcopper80)
 */
@Component
public class JmsQueueConsumer {

    @JmsListener(destination = "demo.queue", containerFactory = "jmsListenerContainerFactory")
    public void receiveQueue(String message) {
        System.out.println("[QUEUE CONSUMER] Received from queue: " + message);
    }
}
