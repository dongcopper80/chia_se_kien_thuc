package com.dongcopper80.jms;

import org.springframework.jms.core.JmsTemplate;

/**
 *
 * @author Nguyễn Thúc Đồng (dongcopper80)
 */
public class JmsTopicProducer {
    
    private JmsTemplate jmsTemplate;

    public void setJmsTemplate(JmsTemplate jmsTemplate) {
        this.jmsTemplate = jmsTemplate;
    }

//    public void publish(String topic, String message) {
//        jmsTemplate.convertAndSend(topic, message);
//        System.out.println("[TOPIC PRODUCER] Published to topic: " + topic + " | Message: " + message);
//    }
    
    public void publish(String topic, String message) {
        jmsTemplate.setPubSubDomain(true);
        jmsTemplate.convertAndSend(topic, message);
        System.out.println("[TOPIC PRODUCER] Published to topic: " + topic + " | Message: " + message);
    }
}
