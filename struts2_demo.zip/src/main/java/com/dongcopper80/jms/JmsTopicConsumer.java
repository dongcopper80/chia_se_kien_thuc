package com.dongcopper80.jms;

//import org.springframework.jms.annotation.JmsListener;
import org.springframework.jms.core.JmsTemplate;
//import org.springframework.stereotype.Component;

/**
 *
 * @author Nguyễn Thúc Đồng (dongcopper80)
 */
//@Component
public class JmsTopicConsumer {

//    @JmsListener(destination = "demo.topic", containerFactory = "jmsTopicListenerContainerFactory", subscription = "sub-001")
//    public void receiveTopic(String message) {
//        System.out.println("[TOPIC CONSUMER] Received from topic: " + message);
//    }
    
    private JmsTemplate jmsTemplate;

    public void setJmsTemplate(JmsTemplate jmsTemplate) {
        this.jmsTemplate = jmsTemplate;
    }
    
    public String consumeTopic(String topic) {
        // Ensure topic mode is enabled
        jmsTemplate.setPubSubDomain(true);

        // Receive message from topic
        Object msg = jmsTemplate.receiveAndConvert(topic);

        if (msg == null) {
            System.out.println("[TOPIC CONSUMER] No new message in topic: " + topic);
            return null;
        }

        String message = msg.toString();
        System.out.println("[TOPIC CONSUMER] Received from topic: " + topic + " | Message: " + message);
        return message;
    }
}
