package com.dongcopper80.jms;

import org.springframework.jms.core.JmsTemplate;

/**
 *
 * @author Nguyễn Thúc Đồng (dongcopper80)
 */
public class JmsProducer {
    
    private JmsTemplate jmsTemplate;

    public void setJmsTemplate(JmsTemplate jmsTemplate) {
        this.jmsTemplate = jmsTemplate;
    }

//    public void sendMessage(String destination, String message) {
//        jmsTemplate.convertAndSend(destination, message);
//    }
    
    public void sendMessage(String destination, String message) {
        jmsTemplate.setPubSubDomain(false);
        jmsTemplate.convertAndSend(destination, message);
        System.out.println("[QUEUE PRODUCER] Sent to queue: " + destination + " | Message: " + message);
    }
}
