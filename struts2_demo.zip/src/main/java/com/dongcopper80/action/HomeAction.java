package com.dongcopper80.action;

import com.dongcopper80.jms.JmsProducer;
import com.dongcopper80.jms.JmsTopicConsumer;
import com.dongcopper80.jms.JmsTopicProducer;
import com.opensymphony.xwork2.ActionSupport;
import org.springframework.beans.factory.annotation.Autowired;

/**
 *
 * @author Nguyễn Thúc Đồng (dongcopper80)
 */
public class HomeAction extends ActionSupport {

    @Autowired
    private JmsProducer jmsProducer;
//
//    @Override
//    public String execute() {
//        jmsProducer.sendMessage("demo.queue", "Hello from Struts2 + Spring + ActiveMQ + Tiles");
//        return SUCCESS;
//    }
    
    @Autowired
    private JmsTopicProducer jmsTopicProducer;
    
    @Autowired
    private JmsTopicConsumer jmsTopicConsumer;

//    @Override
//    public String execute() {
//        jmsProducer.sendMessage("demo.queue", "Hello Queue Event");
//        jmsTopicProducer.publish("demo.topic", "Hello Topic Event");
//        return SUCCESS;
//    }
    
    @Override
    public String execute() {

        // Send to queue
        jmsProducer.sendMessage("demo.queue", "Queue message from Struts2 Action");

        // Publish to topic
        jmsTopicProducer.publish("demo.topic", "Topic message from Struts2 Action");

        // Pull message from topic
        String topicMessage = jmsTopicConsumer.consumeTopic("demo.topic");

        if (topicMessage != null) {
            System.out.println("[ACTION] Topic message consumed successfully: " + topicMessage);
        }

        return SUCCESS;
    }
}
