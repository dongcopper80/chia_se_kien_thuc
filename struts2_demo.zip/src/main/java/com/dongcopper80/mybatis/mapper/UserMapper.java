package com.dongcopper80.mybatis.mapper;

import com.dongcopper80.mybatis.model.User;
import java.util.List;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/**
 *
 * @author Nguyễn Thúc Đồng (dongcopper80)
 */
@Mapper
public interface UserMapper {
    
    User findById(@Param("id") Long id);

    User findByUsername(@Param("username") String username);

    List<User> findAll();

    void insert(User user);

    void update(User user);

    void delete(@Param("id") Long id);
}
